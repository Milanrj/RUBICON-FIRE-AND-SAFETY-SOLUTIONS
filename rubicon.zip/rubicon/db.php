<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "rubicon";
$con = new mysqli($dbhost,$dbuser,$dbpass,$dbname);
?>