
<html>
    <head>
        <title>RUBICON</title>
        <link rel="stylesheet" type="text/css" href="index.css">
        <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no" >
    </head>
    <body>
        <header class="head">       
            <img src="logo.png" alt="rubicon-logo">
            <span  style="font-family:Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;"><span> <div class=bisname>RUBICON FIRE <div> AND SAFETY SOLUTIONS</div></div></span> </span>
            <div class="header_nav">
                <nav >
                    <a style="margin-leftt:50px; " href="#">ABOUT US</a>
                    <a style="margin-left:50px; " href="#">CONTACT US </a>
                    <a style="margin-left:50px; " href="regpage.php">SIGN UP</a>
                    <a style="margin-left:50px; margin-right:50px " href="login.php">SIGN IN</a>
                </nav>
            </div>
        </header>
        <div id="screen">
            <div id="slider">
                <div class="images">
                        <input type="radio" name="slide" id="img1" checked>
                        <input type="radio" name="slide" id="img2">
                        <input type="radio" name="slide" id="img3">
    
                        <img src="page-1_slide01.jpg" class="m1" alt="img1">
                        <img src="page-1_slide02.jpg" class="m2" alt="img2">
                        <img src="page-1_slide03.jpg" class="m3" alt="img3">
                </div>
                <div class="dots">
                        <label for="img1"></label>
                        <label for="img2"></label>
                        <label for="img3"></label>
                </div>
            </div>
            <div class="icons">
                <div class="icon" style="margin-left: 200px;">
                    <img src="icon-1.png"  alt="fire-products" ><br>
                    <p><a>FIRE <br> PRODUCTS</a></p>
                </div>
                <div class="icon" style="margin-left: 300px;">
                    <img src="icon-2.png"  alt="maintenance"><br>
                    <p><a>MAINTENANCE <br>& SERVICE</a></p>
                </div>
                <div class="icon" style="margin-left: 300px;">
                    <img src="icon-3.png"  alt="scanner" style="width:80px;height:80px;"><br>
                    <p>ARCHITECTURAL FLOOR<br> PLAN DETECTOR</p>
                </div>
            </div>
        </div>
    </body>
</html>